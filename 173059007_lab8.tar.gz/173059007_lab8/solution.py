# importing libraries
import pandas as pd 


# converting import and export files to DataFrame
import_df = pd.read_excel('India_Imports_2011-12_And_2012-13.xls')
export_df = pd.read_excel('India_Exports_2011-12_And_2012-13.xls')


"""
Q1) 
A) Top five import and export countries
"""
#print("----------------------------Q1---------------------------------------")

by_country_import = import_df.groupby('Country').sum()
#print(by_country_import)
q1_import_data = by_country_import.sort_values('Value-INR-2011-12', ascending=False).head(5)

q1_import = pd.DataFrame(q1_import_data.index)
q1_import.columns = ['Country']
#print(q1_import)


by_country_export = export_df.groupby('Country').sum()
#print(by_country_import)
q1_export_data = by_country_export.sort_values('Value-INR-2011-12', ascending=False).head(5)
q1_export = pd.DataFrame(q1_export_data.index)
q1_export.columns = ['Country']
#print(q1_export)




"""
Q2) Top five import and export commodities
"""

#print("===============================(Q2)==================================")

by_commodity_import = import_df.groupby('Commodity').sum()
#print(by_country_import)
q2_import_data = by_commodity_import.sort_values('Value-INR-2011-12', ascending=False).head(5)
q2_import = pd.DataFrame(q2_import_data.index)
q2_import.columns = ['Country']
#print(q2_import)


by_commodity_export = export_df.groupby('Commodity').sum()
#print(by_country_import)
q2_export_data = by_commodity_export.sort_values('Value-INR-2011-12', ascending=False).head(5)
q2_export = pd.DataFrame(q2_export_data.index)
q2_export.columns = ['Country']
#print(q2_export)


"""
Q3) Single Table (Total Import , Total Export, export/import, export - import(deficit))
"""

#print("=====================================Q3=====================================")

import_and_export_concat = pd.concat([by_country_import, by_country_export], axis=1)
#print(import_and_export_concat.head())

import_and_export_concat.columns =['im-quantity-2011-12', 'im-value-2011-12','im-quantity-2012-13', 'im-value-2012-13','ex-quantity-2011-12', 'ex-value-2011-12','ex-quantity-2012-13', 'ex-value-2012-13']
#print(import_and_export_concat.head())


import_and_export = import_and_export_concat[['im-value-2011-12', 'ex-value-2011-12']]
import_and_export.columns = ['Total_Import', 'Total_Export']
#print(import_and_export.head())

#export/import
export_by_import = pd.DataFrame(import_and_export_concat['ex-value-2011-12'].div(import_and_export_concat['im-quantity-2011-12'], axis=0))
export_by_import.columns = ['Export/Import']
#print(export_by_import.head())

# export - import
#print("deficit")
deficit =pd.DataFrame(import_and_export_concat['ex-value-2011-12'] - import_and_export_concat['im-value-2011-12'])
#print(type(deficit))
deficit.columns = ['Export - Import (Deficit)']
#print(deficit.head())


q3 = pd.concat([import_and_export, export_by_import, deficit ], axis=1)
#print("before")
#print(q3.head())
#print("after")
q3['Country'] = q3.index
q3 = q3[['Country', 'Total_Import', 'Total_Export','Export/Import', 'Export - Import (Deficit)']]
#print(q3.head()) 


"""
Q4)  Countries whose export is greater tha rs 10,000 Cr
"""

#print("=====================================Q4=====================================")


q4 = q3.query('Total_Export > 1e11')
#print(q4.head())


"""
Q5) Save answer to Q4. in new table(Country, Exports, Imports) 
"""
#print("=====================================Q5=====================================")

pd.options.mode.chained_assignment = None

table = q4[['Total_Export', 'Total_Import']]
table['Country'] = table.index
table = table[['Country','Total_Export', 'Total_Import']]
table.columns = ['Country', 'Export', 'Import']
q5 = table
#print(q5.head())


"""
Q6) melt 
"""
#print("=====================================Q6=====================================")


q6_data = pd.melt(q5, id_vars=['Country'], value_vars=['Export','Import'])
q6= q6_data.sort_values('value', ascending=False).head(10)
q6.columns = ['Country', 'Transaction', 'Value']
#ans =q6.reset_index(drop=True)
#print(q6)

"""
Q7) Make a table of commodities that we both export and import
"""
#print("=====================================Q7=====================================")

q7_data = pd.concat([by_commodity_import, by_commodity_export], axis=1)

q7_data.columns =['im-quantity-2011-12', 'im-value-2011-12','im-quantity-2012-13', 'im-value-2012-13','ex-quantity-2011-12', 'ex-value-2011-12','ex-quantity-2012-13', 'ex-value-2012-13']


q7_data['Total_Export'] = q7_data['ex-value-2011-12'] + q7_data['ex-value-2012-13']
q7_data['Total_Import'] = q7_data['im-value-2011-12'] + q7_data['ex-value-2012-13']

q7_data = q7_data[['Total_Export', 'Total_Import']]

q7 = q7_data.dropna(axis=0, how='any')
q7_ans = pd.DataFrame(q7.index)
q7_ans.columns = ['Commodity']

#print(q7_ans)



"""
Writing to Excel File
"""

writer = pd.ExcelWriter("173059007_Solution.xls")
q1_import.to_excel(writer, 'Q1_Import', index=False)
q1_export.to_excel(writer, 'Q1_Export', index=False)

q2_import.to_excel(writer, 'Q2_Import', index=False)
q2_export.to_excel(writer, 'Q2_Export', index=False)

q3.to_excel(writer, 'Q3', index=False)
q4.to_excel(writer, 'Q4', index=False)
q5.to_excel(writer, 'Q5', index=False)
q6.to_excel(writer,'Q6', index=False)
q7_ans.to_excel(writer,'Q7', index=False)
writer.save()

print("Completed")
